# PROG5121 Part 2 - QuickChat

Student: Nandi Shannon Nkosi
Student Number: ST10547934

This Maven project follows the console sequence demonstrated in the supplied Part 2 video:
registration, login, number of messages, QuickChat menu, message creation, message validation,
send/disregard/store action, and the total sent-message count.

The "Show recently sent messages" option displays "Coming Soon." because that is the behaviour
shown in the supplied demonstration video.
