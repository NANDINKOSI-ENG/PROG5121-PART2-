package com.mycompany.prog5121part1;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MessageTest {
    @Test
    void messageIdCannotExceedTenDigits() {
        assertTrue(new Message("1234567890", 0, "+27718693002", "Hello").isValidMessageId());
        assertFalse(new Message("12345678901", 0, "+27718693002", "Hello").isValidMessageId());
    }

    @Test
    void recipientMustUseInternationalFormat() {
        Message valid = new Message("1234567890", 0, "+27718693002", "Hello");
        Message invalid = new Message("1234567890", 0, "08575975889", "Hello");

        assertEquals("Cell phone number successfully captured.", valid.validateRecipient());
        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                invalid.validateRecipient()
        );
    }

    @Test
    void messageMustBeWithin250Characters() {
        Message valid = new Message("0012345678", 0, "+27718693002", "Hi Mike");
        Message invalid = new Message("0012345678", 0, "+27718693002", "a".repeat(251));

        assertTrue(valid.isWithinCharacterLimit());
        assertFalse(invalid.isWithinCharacterLimit());
    }

    @Test
    void messageHashUsesRequiredFormat() {
        Message message = new Message(
                "4212345678",
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals("42:0:HITONIGHT", message.buildMessageHash());
    }

    @Test
    void generatedMessageIdHasTenDigits() {
        String generatedId = Message.createMessageId(0);
        assertTrue(generatedId.matches("\\d{10}"));
    }
}
