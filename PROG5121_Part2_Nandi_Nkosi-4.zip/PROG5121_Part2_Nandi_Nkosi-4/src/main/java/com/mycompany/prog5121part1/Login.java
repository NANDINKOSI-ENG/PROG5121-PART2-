package com.mycompany.prog5121part1;

import java.util.regex.Pattern;

/** Stores the details needed for registration and login. */
public class Login {
    private String userName, userPassword, mobileNumber, givenName, familyName;

    public Login(String userName, String userPassword, String mobileNumber, String givenName, String familyName) {
        this.userName=userName; this.userPassword=userPassword; this.mobileNumber=mobileNumber;
        this.givenName=givenName; this.familyName=familyName;
    }
    public boolean validateUserName() { return userName != null && userName.contains("_") && userName.length() <= 5; }
    public boolean validatePassword() {
        if (userPassword == null || userPassword.length() < 8) return false;
        return userPassword.matches(".*[A-Z].*") && userPassword.matches(".*\\d.*")
                && userPassword.matches(".*[^a-zA-Z0-9].*");
    }
    public boolean validateMobileNumber() {
        return mobileNumber != null && Pattern.matches("^\\+27[6-8]\\d{8}$", mobileNumber);
    }
    public String completeRegistration() {
        if (!validateUserName()) return "Username is not correctly formatted; please ensure that your userName contains an underscore and is no more than five characters in length.";
        if (!validatePassword()) return "Password is not correctly formatted; please ensure that the userPassword contains at least eight characters, a capital letter, a number, and a special character.";
        if (!validateMobileNumber()) return "Cell phone number incorrectly formatted or does not contain international code.";
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }
    public boolean authenticate(String u, String p) { return userName.equals(u) && userPassword.equals(p); }
    public String getLoginMessage(boolean status) {
        return status ? "Welcome " + givenName + ", " + familyName + " it is great to see you again."
                : "Username or userPassword incorrect, please try again.";
    }
    public String getUserName() { return userName; }
}
