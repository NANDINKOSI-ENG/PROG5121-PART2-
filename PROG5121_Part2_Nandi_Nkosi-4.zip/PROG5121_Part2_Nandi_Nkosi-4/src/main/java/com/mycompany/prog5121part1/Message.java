package com.mycompany.prog5121part1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;

/** Represents a QuickChat message and performs the required message operations. */
public class Message {
    private static int sentMessageCount = 0;

    private final String messageIdentifier;
    private final int sequenceNumber;
    private final String recipientNumber;
    private final String message;
    private String messageStatus = "Pending";

    public Message(String messageIdentifier, int sequenceNumber,
                   String recipientNumber, String message) {
        this.messageIdentifier = messageIdentifier;
        this.sequenceNumber = sequenceNumber;
        this.recipientNumber = recipientNumber;
        this.message = message;
    }

    public boolean isValidMessageId() {
        return messageIdentifier != null && messageIdentifier.matches("\\d{1,10}");
    }

    public String validateRecipient() {
        if (recipientNumber != null
                && Pattern.matches("^\\+27[6-8]\\d{8}$", recipientNumber)) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String buildMessageHash() {
        if (messageIdentifier == null || messageIdentifier.length() < 2 || message == null) {
            return "";
        }

        String cleanedMessage = message.trim();
        if (cleanedMessage.isEmpty()) {
            return messageIdentifier.substring(0, 2) + ":" + sequenceNumber + ":";
        }

        String[] words = cleanedMessage.split("\\s+");
        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");

        return (messageIdentifier.substring(0, 2)
                + ":" + sequenceNumber + ":" + firstWord + lastWord)
                .toUpperCase(Locale.ROOT);
    }

    public String processMessage(Scanner input) {
        System.out.println("Choose what to do with this message:");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        System.out.print("Choose an option: ");

        switch (input.nextLine()) {
            case "1":
                messageStatus = "Sent";
                sentMessageCount++;
                return "Message successfully sent.";
            case "2":
                messageStatus = "Disregarded";
                return "Press 0 to delete the message.";
            case "3":
                messageStatus = "Stored";
                saveToFile();
                return "Message successfully stored.";
            default:
                return "Invalid option. Please choose 1, 2 or 3.";
        }
    }

    public String displayMessage() {
        return "Message ID: " + messageIdentifier
                + "\nMessage Hash: " + buildMessageHash()
                + "\nRecipient: " + recipientNumber
                + "\nMessage: " + message;
    }

    public static int getSentMessageCount() {
        return sentMessageCount;
    }

    public String getMessageStatus() {
        return messageStatus;
    }

    public boolean isWithinCharacterLimit() {
        return message != null && message.length() <= 250;
    }

    public String getMessageContent() {
        return message;
    }

    public void saveToFile() {
        Path file = Path.of("stored_messages.json");
        String object = "{\"messageIdentifier\":\"" + escapeJson(messageIdentifier)
                + "\",\"messageHash\":\"" + escapeJson(buildMessageHash())
                + "\",\"sequenceNumber\":" + sequenceNumber
                + ",\"recipientNumber\":\"" + escapeJson(recipientNumber)
                + "\",\"message\":\"" + escapeJson(message) + "\"}";

        try {
            String oldContent = Files.exists(file)
                    ? Files.readString(file, StandardCharsets.UTF_8).trim()
                    : "";

            String updatedContent;
            if (oldContent.isEmpty() || oldContent.equals("[]")) {
                updatedContent = "[" + object + "]";
            } else {
                updatedContent = oldContent.substring(0, oldContent.length() - 1)
                        + "," + object + "]";
            }

            Files.writeString(
                    file,
                    updatedContent,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING
            );
        } catch (IOException exception) {
            System.out.println("Unable to store the message: " + exception.getMessage());
        }
    }

    public static String createMessageId(int sequenceNumber) {
        return String.format(
                "%02d%08d",
                ThreadLocalRandom.current().nextInt(100),
                ThreadLocalRandom.current().nextInt(100_000_000)
        );
    }

    private static String escapeJson(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("\t", "\\t");
    }
}
