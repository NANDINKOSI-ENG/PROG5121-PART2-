package com.mycompany.prog5121part1;

import java.util.ArrayList;
import java.util.Scanner;

/** Controls the registration, login and QuickChat console flow. */
public class Prog5121part1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();
        boolean applicationRunning = true;

        System.out.println("Welcome to the Registration and Login App!");

        while (applicationRunning) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Please choose an option: ");

            switch (input.nextLine()) {
                case "1":
                    registerNewUser(input, users);
                    break;
                case "2":
                    loginUser(input, users);
                    break;
                case "3":
                    System.out.println("\nGoodbye!");
                    applicationRunning = false;
                    break;
                default:
                    System.out.println("\nInvalid option. Please choose 1, 2 or 3.");
            }
        }

        input.close();
    }

    private static void registerNewUser(Scanner input, ArrayList<Login> users) {
        System.out.println("\n=== Registration ===");
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter userName: ");
        String userName = input.nextLine();

        System.out.print("Enter userPassword: ");
        String userPassword = input.nextLine();

        System.out.print("Enter a South African cell phone number (e.g. +27838968976): ");
        String cellNumber = input.nextLine();

        Login account = new Login(userName, userPassword, cellNumber, firstName, lastName);
        System.out.println("\n" + account.completeRegistration());

        if (!account.validateUserName()
                || !account.validatePassword()
                || !account.validateMobileNumber()) {
            return;
        }

        for (Login registeredUser : users) {
            if (registeredUser.getUserName().equals(userName)) {
                System.out.println("Username already exists. Please choose another userName.");
                return;
            }
        }

        users.add(account);
        System.out.println("User registered successfully!");
        System.out.println("You can now choose Login from the Main Menu.");
    }

    private static void loginUser(Scanner input, ArrayList<Login> users) {
        if (users.isEmpty()) {
            System.out.println("\nNo users are registered yet. Please register first.");
            return;
        }

        System.out.println("\n=== Login ===");
        System.out.print("Enter userName: ");
        String enteredUserName = input.nextLine();

        System.out.print("Enter userPassword: ");
        String enteredPassword = input.nextLine();

        for (Login account : users) {
            if (account.getUserName().equals(enteredUserName)) {
                boolean loginSuccessful = account.authenticate(
                        enteredUserName,
                        enteredPassword
                );

                System.out.println(account.getLoginMessage(loginSuccessful));

                if (loginSuccessful) {
                    runQuickChat(input);
                }
                return;
            }
        }

        System.out.println("Username or userPassword incorrect, please try again.");
    }

    /** Runs QuickChat in the same sequence shown in the supplied demonstration video. */
    private static void runQuickChat(Scanner input) {
        System.out.println("\nWelcome to QuickChat.");
        System.out.print("How many messages would you like to enter? ");
        int totalMessages = readPositiveNumber(input);
        int messagesEntered = 0;

        while (true) {
            System.out.println("\nQuickChat Menu:");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Please choose an option: ");

            switch (input.nextLine()) {
                case "1":
                    if (messagesEntered >= totalMessages) {
                        System.out.println("You have entered the set number of messages.");
                        break;
                    }

                    createAndProcessMessage(input, messagesEntered);
                    messagesEntered++;
                    break;

                case "2":
                    // This option is intentionally left as Coming Soon, matching the video.
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    System.out.println("Returning to the main menu.");
                    System.out.println("\nTotal messages sent: " + Message.getSentMessageCount());
                    return;

                default:
                    System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }

    private static void createAndProcessMessage(Scanner input, int messageNumber) {
        String messageId = Message.createMessageId(messageNumber);

        System.out.println("\n=== Send Message " + (messageNumber + 1) + " ===");
        System.out.println("Message ID generated: " + messageId);

        System.out.print("Enter recipient cell number: ");
        String recipient = input.nextLine();

        System.out.print("Enter your message: ");
        String messageText = input.nextLine();

        Message message = new Message(
                messageId,
                messageNumber,
                recipient,
                messageText
        );

        System.out.println("Message Hash: " + message.buildMessageHash());

        if (!message.validateRecipient().equals("Cell phone number successfully captured.")) {
            System.out.println("Please correct the number and try again.");
            return;
        }

        if (!message.isWithinCharacterLimit()) {
            System.out.println(
                    "Message exceeds 250 characters by "
                            + (message.getMessageContent().length() - 250)
                            + "; please reduce the size."
            );
            return;
        }

        String actionResult = message.processMessage(input);
        System.out.println(actionResult);
        System.out.println();
        System.out.println(message.displayMessage());
    }

    private static int readPositiveNumber(Scanner input) {
        while (true) {
            try {
                int requestedMessages = Integer.parseInt(input.nextLine());
                if (requestedMessages > 0) {
                    return requestedMessages;
                }
            } catch (NumberFormatException ignored) {
                // Continue asking until a positive whole number is entered.
            }

            System.out.print("Please enter a number greater than zero: ");
        }
    }
}
